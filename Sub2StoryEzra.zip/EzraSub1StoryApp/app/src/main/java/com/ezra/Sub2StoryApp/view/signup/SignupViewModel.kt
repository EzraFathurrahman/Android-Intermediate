package com.ezra.Sub2StoryApp.view.signup

import android.content.Context

import android.util.Log

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

import com.ezra.Sub2StoryApp.ApiConfig
import com.ezra.Sub2StoryApp.FileUploadResponse

import com.ezra.Sub2StoryApp.model.UserPreference

import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response


class SignupViewModel (private val pref: UserPreference): ViewModel() {

    private val _apiCheck = MutableLiveData<String>()
    val apiCheck: MutableLiveData<String> = _apiCheck

    companion object{
        private const val TAG = "SignupActivity"
    }

    fun register(context: Context, name:String, email:String,password:String){
    val service= ApiConfig.getApiService().createUser(name,email,password)
    service.enqueue(object : Callback<FileUploadResponse> {
        override fun onResponse(
            call: Call<FileUploadResponse>,
            response: Response<FileUploadResponse>
        ) {
            val responseBody = response.body()
            if (response.isSuccessful) {
                if (responseBody != null && !responseBody.error) {
                    val error = responseBody.error
                    if (!error){
                        _apiCheck.value = responseBody.message
                    }else{
                        _apiCheck.value = "Failed to create user"
                    }
                } else {
                    _apiCheck.value = "Successfully created user"
            }
        }}
        override fun onFailure(call: Call<FileUploadResponse>, t: Throwable) {
                _apiCheck.value = t.message
                Log.e(TAG, "onFailure: ${t.message}")
        }
    })

} }










