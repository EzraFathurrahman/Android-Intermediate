package com.ezra.Sub2StoryApp.view.main

import com.ezra.Sub2StoryApp.ListStory
import com.ezra.Sub2StoryApp.ApiService
import androidx.paging.PagingSource
import androidx.paging.PagingState
import com.ezra.Sub2StoryApp.model.UserPreference
import kotlinx.coroutines.flow.first

class MainPagingSource(private val apiService: ApiService, val token:String,private val userPreference: UserPreference) : PagingSource<Int, ListStory>() {



    private companion object {
        const val INITIAL_PAGE_INDEX = 1
    }

    override suspend fun load(params: LoadParams<Int>): LoadResult<Int, ListStory> {
        return try {
            val page = params.key ?: INITIAL_PAGE_INDEX
            var token2 = "Bearer " + userPreference.getUser().first().token
            val responseData = apiService.getPagingStory(page, params.loadSize, token2)


            LoadResult.Page(
                data = responseData.listStory,
                prevKey = if (page == 1) null else page - 1,
                nextKey = if (responseData.listStory.isNullOrEmpty()) null else page + 1
            )
        } catch (exception: Exception) {
            return LoadResult.Error(exception)
        }
    }

    override fun getRefreshKey(state: PagingState<Int, ListStory>): Int? {
        return state.anchorPosition?.let { anchorPosition ->
            val anchorPage = state.closestPageToPosition(anchorPosition)
            anchorPage?.prevKey?.plus(1) ?: anchorPage?.nextKey?.minus(1)
        }
    }
}