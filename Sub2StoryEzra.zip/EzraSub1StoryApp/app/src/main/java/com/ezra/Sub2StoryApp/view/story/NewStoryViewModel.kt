package com.ezra.Sub2StoryApp.view.story

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.asLiveData
import com.ezra.Sub2StoryApp.model.UserModel
import com.ezra.Sub2StoryApp.model.UserPreference

class NewStoryViewModel (private val pref: UserPreference) : ViewModel(){
    fun getUser(): LiveData<UserModel> {
        return pref.getUser().asLiveData()
    }

}