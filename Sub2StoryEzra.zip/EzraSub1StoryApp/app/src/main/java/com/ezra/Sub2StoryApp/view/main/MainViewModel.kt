package com.ezra.Sub2StoryApp.view.main


import android.util.Log
import androidx.lifecycle.*
import com.ezra.Sub2StoryApp.*

import com.ezra.Sub2StoryApp.model.UserModel
import com.ezra.Sub2StoryApp.model.UserPreference
import kotlinx.coroutines.launch
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MainViewModel(private val pref: UserPreference) : ViewModel() {

    val listStoriesUser = MutableLiveData<ArrayList<ListStory>>()
    val listMapStoriesUser = MutableLiveData<List<ListStory>>()
    val listMapStory : LiveData<List<ListStory>> get() = listMapStoriesUser
    private val _responseApi = MutableLiveData<String>()


    fun getUser(): LiveData<UserModel> {
        return pref.getUser().asLiveData()
    }
    companion object{
            private const val TAG = "MainActivity"
    }

    fun getStoryList(token:String){
        val listStories=ArrayList<ListStory>()
        val client= ApiConfig.getApiService().getStory("Bearer " +token)
        client.enqueue(object : Callback<ResponseStory> {
            override fun onResponse(
                call: Call<ResponseStory>,
                response: Response<ResponseStory>
            ) {
                val responseBody = response.body()
                if (responseBody != null &&response.isSuccessful)
                     {
                         listStoriesUser.postValue(responseBody.listStory)
                         listStoriesUser.value=listStories
                         val error = responseBody.error
                         Log.d(TAG,"User Token: "+token)

                         _responseApi.value = "Story success"

                    } else {
                        _responseApi.value = responseBody?.message
                        Log.e(TAG, "onFailure: ${response.message()}")
                    }
                }
            override fun onFailure(call: Call<ResponseStory>, t: Throwable) {
                _responseApi.value = t.message
                Log.e(TAG, "onFailure: ${t.message}")
            }
        })



    }
    fun getMapStoryList(token:String){
        val listStories=ArrayList<ListStory>()
        val client= ApiConfig.getApiService().getMapStoryLoc("Bearer " +token,1)
        client.enqueue(object : Callback<ResponseStory> {
            override fun onResponse(
                call: Call<ResponseStory>,
                response: Response<ResponseStory>
            ) {
                val responseBody = response.body()
                if (responseBody != null &&response.isSuccessful)
                {
                    Log.d("MapsActivity",responseBody.toString())
                    listMapStoriesUser.postValue(responseBody.listStory)
                    listMapStoriesUser.value=listStories

                } else {
                    _responseApi.value = responseBody?.message
                    Log.e(TAG, "onFailure: ${response.message()}")
                }
            }
            override fun onFailure(call: Call<ResponseStory>, t: Throwable) {
                _responseApi.value = t.message
                Log.e(TAG, "onFailure: ${t.message}")
            }
        })

    }

    fun logout() {
        viewModelScope.launch {
            pref.logout()
        }
    }

}