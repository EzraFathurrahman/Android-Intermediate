package com.ezra.Sub2StoryApp.view.main

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import com.ezra.Sub2StoryApp.ListStory
import com.ezra.Sub2StoryApp.databinding.ActivityStoryDetailBinding


class StoryDetailActivity : AppCompatActivity() {
    companion object {
    const val DETAIL_DATA = "detail_data"
}
    private lateinit var binding: ActivityStoryDetailBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityStoryDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val storyData = intent.getParcelableExtra<ListStory>(DETAIL_DATA) as ListStory
            Glide.with(this)
                .load(storyData.photoUrl)
                .into(binding.dtStory)
        binding.apply{
            dtName.text=storyData.name
            dtDesc.text=storyData.description
        }


    }
    }