package com.ezra.Sub2StoryApp.view.main

import android.app.Activity
import android.content.Intent
import android.util.Log
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.app.ActivityOptionsCompat
import androidx.core.util.Pair
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.ezra.Sub2StoryApp.ListStory
import com.ezra.Sub2StoryApp.databinding.ItemRowStoryBinding
import com.ezra.Sub2StoryApp.view.main.StoryDetailActivity.Companion.DETAIL_DATA


class ListStoryUserAdapter(private val users: ArrayList<ListStory>) : RecyclerView.Adapter<ListStoryUserAdapter.UserViewHolder>() {

    private lateinit var onItemClickCallback: OnItemClickCallback

    fun setOnItemClickCallback(onItemClickCallback: OnItemClickCallback) {
        this.onItemClickCallback = onItemClickCallback
    }

    inner class UserViewHolder(private var binding: ItemRowStoryBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(user: ListStory) {
            binding.apply {
                tvName.text = user.name
                Glide.with(itemView.context)
                    .load(user.photoUrl)
                    .into(story)
            itemView.setOnClickListener {
                onItemClickCallback?.onItemClicked(user)
                val intent = Intent(itemView.context, StoryDetailActivity::class.java)
                intent.putExtra(DETAIL_DATA, user)
                Log.d("Test data", "Detail Data")

                val optionsCompat: ActivityOptionsCompat =
                    ActivityOptionsCompat.makeSceneTransitionAnimation(
                        itemView.context as Activity,
                        Pair(story, "story"),
                        Pair(tvName, "name"),
                    )
                itemView.context.startActivity(intent, optionsCompat.toBundle())

                notifyDataSetChanged()
            }
        }}
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): UserViewHolder {
        val view = ItemRowStoryBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return UserViewHolder(view)
    }

    override fun onBindViewHolder(holder: UserViewHolder, position: Int) {
        val data = getItemViewType(position)
        holder.bind(users[position])
//        holder.itemView.setOnClickListener { getItemViewType(holder.adapterPosition)?.let{it1 ->
//            onItemClickCallback.onItemClicked(
//                it1
//            )
//        } }
    }

    override fun getItemCount(): Int {
        return users.size
    }
    interface OnItemClickCallback {
        fun onItemClicked(data: ListStory)
    }
}