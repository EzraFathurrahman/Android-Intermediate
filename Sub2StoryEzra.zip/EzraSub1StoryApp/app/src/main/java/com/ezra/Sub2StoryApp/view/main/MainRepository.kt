package com.ezra.Sub2StoryApp.view.main


import androidx.lifecycle.LiveData
import androidx.paging.Pager
import androidx.paging.PagingConfig
import androidx.paging.PagingData
import androidx.paging.liveData
import com.ezra.Sub2StoryApp.ApiService
import com.ezra.Sub2StoryApp.ListStory
import com.ezra.Sub2StoryApp.model.UserPreference

class MainRepository(private val quoteDatabase: PagingDatabase, private val apiService: ApiService,val token:String, private val userPreference: UserPreference) {
    fun getQuote(): LiveData<PagingData<ListStory>> {
        return Pager(
            config = PagingConfig(
                pageSize = 5
            ),
            pagingSourceFactory = {
                MainPagingSource(apiService,token,userPreference)
            }
        ).liveData
    }
}