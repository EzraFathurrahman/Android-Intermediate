package com.ezra.Sub2StoryApp.view.login

import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.view.WindowInsets
import android.view.WindowManager
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.preferencesDataStore
import androidx.lifecycle.ViewModelProvider
import com.ezra.Sub2StoryApp.databinding.ActivityLoginBinding
import com.ezra.Sub2StoryApp.model.UserModel
import com.ezra.Sub2StoryApp.model.UserPreference
import com.ezra.Sub2StoryApp.view.ViewModelFactory
import com.ezra.Sub2StoryApp.view.main.MainActivity

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "settings")

class LoginActivity : AppCompatActivity() {
    private lateinit var loginViewModel: LoginViewModel
    private lateinit var binding: ActivityLoginBinding
    private lateinit var user: UserModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupView()
        setupViewModel()
        setupAction()
        playAnimation()
    }

    private fun setupView() {
        @Suppress("DEPRECATION")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            window.insetsController?.hide(WindowInsets.Type.statusBars())
        } else {
            window.setFlags(
                WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN
            )
        }
        supportActionBar?.hide()
    }

    private fun setupViewModel() {
        loginViewModel = ViewModelProvider(
            this,
            ViewModelFactory(UserPreference.getInstance(dataStore))
        )[LoginViewModel::class.java]

        loginViewModel.getUser().observe(this, { user ->
            this.user = user

            if(this.user.isLogin){
                Intent(this@LoginActivity,MainActivity::class.java).let {
                    it.putExtra(MainActivity.MAIN_TOKEN,user.token)
                    startActivity(it)
                }
            }

        })

    }
    private fun playAnimation() {
        ObjectAnimator.ofFloat(binding.imageView, View.TRANSLATION_X, -30f, 30f).apply {
            duration = 5000
            repeatCount = ObjectAnimator.INFINITE
            repeatMode = ObjectAnimator.REVERSE
        }.start()

        val title = ObjectAnimator.ofFloat(binding.titleTextView, View.ALPHA, 1f).setDuration(400)
        val message = ObjectAnimator.ofFloat(binding.messageTextView, View.ALPHA, 1f).setDuration(400)
        val emailTextView = ObjectAnimator.ofFloat(binding.emailTextView, View.ALPHA, 1f).setDuration(400)
        val emailEditTextLayout = ObjectAnimator.ofFloat(binding.editEmail, View.ALPHA, 1f).setDuration(400)
        val passwordTextView = ObjectAnimator.ofFloat(binding.passwordTextView, View.ALPHA, 1f).setDuration(400)
        val passwordEditTextLayout = ObjectAnimator.ofFloat(binding.edtPass, View.ALPHA, 1f).setDuration(400)
        val login = ObjectAnimator.ofFloat(binding.loginButton, View.ALPHA, 1f).setDuration(400)

        AnimatorSet().apply {
            playSequentially(title, message, emailTextView, emailEditTextLayout, passwordTextView, passwordEditTextLayout, login)
            startDelay = 400
        }.start()
    }

    private fun setupAction() {
        binding.loginButton.setOnClickListener {
            val email = binding.editEmail.text.toString()
            val password = binding.edtPass.text.toString()
            loginViewModel.userLogin(this,email,password)

            if(!ValidEmail(email)){
                binding.editEmail.error="Masukkan Email Valid"
            }
            else if(!ValidPass(password)){
                binding.edtPass.error="Password Tidak Valid!"

            }
            else {
                loginViewModel.userLogin(this,email,password)
            }
        }
    }
    fun ValidEmail(s:String): Boolean{
        if(s.isEmpty()) return false
        else return android.util.Patterns.EMAIL_ADDRESS.matcher(s).matches();
    }

    fun ValidPass(password: String) : Boolean{
        if(password.isEmpty()) return false
        return password.length >= 6

    }


}