package com.ezra.Sub2StoryApp

import com.ezra.Sub2StoryApp.view.login.loginResponse
import okhttp3.MultipartBody
import okhttp3.RequestBody
import retrofit2.Call
import retrofit2.http.Multipart
import retrofit2.http.POST
import retrofit2.http.*

interface ApiService {

    @FormUrlEncoded
    @POST("register")
    fun createUser(
        @Field("name")
        name: String,
        @Field("email")
        email: String,
        @Field("password")
        password: String,
    ): Call<FileUploadResponse>

    @FormUrlEncoded
    @POST("login")
    fun loginUser(
        @Field("email")
        email: String,
        @Field("password")
        password: String,
    ): Call<loginResponse>

    @GET("stories")
    fun getStory(
        @Header("Authorization")
        token: String
    ) : Call<ResponseStory>

    @GET("stories")
    suspend fun getPagingStory(
        @Query("page") page: Int,
        @Query("size") size: Int,
        @Header("Authorization")
        token: String
    ) : ResponseStory

    @GET("stories")
    fun getMapStoryLoc(
        @Header("Authorization") token: String,
        @Query("location") location: Int
    ) : Call<ResponseStory>


    @Multipart
    @POST("stories")
    fun uploadStory(
        @Header("Authorization")
        token: String,
        @Part("description")
        description: RequestBody,
        @Part file: MultipartBody.Part,

    ): Call<ResponseStory>


}