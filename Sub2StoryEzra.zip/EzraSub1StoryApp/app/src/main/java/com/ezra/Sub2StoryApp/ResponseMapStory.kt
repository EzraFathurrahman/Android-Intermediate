package com.ezra.Sub2StoryApp

import com.google.gson.annotations.SerializedName

data class ResponseMapStory(
    @field:SerializedName("listStory")
    val listStory:ArrayList<ListMapItem>,

    @field:SerializedName("error")
    val error: Boolean,

    @field:SerializedName("message")
    val message: String
)
