package com.ezra.Sub2StoryApp.view.login

import com.google.gson.annotations.SerializedName

data class loginData(

    @field:SerializedName("userId")
    val userId: String,
    @field:SerializedName("name")
    val name: String,
    @field:SerializedName("token")
    val token: String

)
