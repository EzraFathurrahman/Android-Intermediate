package com.ezra.Sub2StoryApp.view.main


import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import androidx.appcompat.app.AppCompatActivity
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.preferencesDataStore
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.ezra.Sub2StoryApp.ListStory
import com.ezra.Sub2StoryApp.R
import com.ezra.Sub2StoryApp.databinding.ActivityMainBinding
import com.ezra.Sub2StoryApp.model.UserPreference
import com.ezra.Sub2StoryApp.view.ViewModelFactory
import com.ezra.Sub2StoryApp.view.maps.MapsActivity
import com.ezra.Sub2StoryApp.view.story.NewStoryActivity
import com.ezra.Sub2StoryApp.view.welcome.WelcomeActivity
import androidx.activity.viewModels
import androidx.core.app.ActivityOptionsCompat
import androidx.lifecycle.asLiveData
import kotlinx.coroutines.flow.first

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "settings")

class MainActivity : AppCompatActivity() {
    private lateinit var mainViewModel: MainViewModel
    private lateinit var binding: ActivityMainBinding
    private lateinit var userPreference: UserPreference

    private val pagingViewModel: PagingViewModel by viewModels {
    ViewModelFactory(this, "Bearer ",UserPreference.getInstance(dataStore))
}

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setupViewModel()



        mainViewModel.getUser().observe(this) { user ->
            if (user.isLogin) {
                user.token.let { mainViewModel.getStoryList(user.token) }
            }
        }


        binding.StoryRv.layoutManager=LinearLayoutManager(this)
        getData()


    }
    override fun onBackPressed() {
        val intent = Intent(Intent.ACTION_MAIN)
        intent.addCategory(Intent.CATEGORY_HOME)
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
        startActivity(intent)
    }




    private fun getData() {
        val adapter = PagingListAdapter()
        binding.StoryRv.adapter = adapter
        pagingViewModel.quote.observe(this, {
            adapter.submitData(lifecycle, it)
        })
        adapter.setOnItemClickCallback(object : PagingListAdapter.OnItemClickCallback {
            override fun onItemClicked(data: ListStory) {

                val moveWithObjectIntent = Intent(this@MainActivity, StoryDetailActivity::class.java)
                moveWithObjectIntent.putExtra(StoryDetailActivity.DETAIL_DATA, data)
                startActivity(moveWithObjectIntent)

            }
        })

    }

    private fun setupViewModel() {
        mainViewModel = ViewModelProvider(
            this,
            ViewModelFactory(UserPreference.getInstance(dataStore))
        )[MainViewModel::class.java]

        mainViewModel.getUser().observe(this, { user ->
            if (user.isLogin){
                supportActionBar?.title = "Halo ${user.name}"
            } else {
                startActivity(Intent(this, WelcomeActivity::class.java))
                finish()
            }
        })
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.option_menu, menu)
        return super.onCreateOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.map -> {
                mainViewModel.getUser().observe(this,{ user ->
                    Intent(this,MapsActivity::class.java).let {
                        it.putExtra(MapsActivity.MAP_TOKEN,user.token)
                        startActivity(it)
                    }
                })

            }
            R.id.camera -> {
                mainViewModel.getUser().observe(this,{ user ->
                    Intent(this,NewStoryActivity::class.java).let {
                        it.putExtra(NewStoryActivity.STORY_TOKEN,user.token)
                        startActivity(it)
                    }
                })
            }
            R.id.logout -> {
                mainViewModel.logout()
            }

        }
        return super.onOptionsItemSelected(item)
    }


    companion object {
        const val CAMERA_X_RESULT = 200
        const val MAIN_TOKEN = "main_token"
    }


}