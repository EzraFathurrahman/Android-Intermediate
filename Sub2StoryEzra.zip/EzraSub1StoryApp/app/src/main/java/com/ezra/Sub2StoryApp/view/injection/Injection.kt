package com.ezra.Sub2StoryApp.view.injection

import android.content.Context
import com.ezra.Sub2StoryApp.ApiConfig
import com.ezra.Sub2StoryApp.model.UserPreference
import com.ezra.Sub2StoryApp.view.main.MainRepository
import com.ezra.Sub2StoryApp.view.main.PagingDatabase

object Injection {
    fun provideRepository(context: Context, token:String, userPreference: UserPreference): MainRepository {
        val database = PagingDatabase.getDatabase(context)
        val apiService = ApiConfig.getApiService()
        return MainRepository(database, apiService, token,userPreference)
    }
}