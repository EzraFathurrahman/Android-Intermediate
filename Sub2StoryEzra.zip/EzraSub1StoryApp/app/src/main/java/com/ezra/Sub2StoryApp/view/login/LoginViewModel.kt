package com.ezra.Sub2StoryApp.view.login

import android.content.Context
import android.util.Log
import androidx.lifecycle.*
import com.ezra.Sub2StoryApp.ApiConfig
import com.ezra.Sub2StoryApp.model.UserModel
import com.ezra.Sub2StoryApp.model.UserPreference
import kotlinx.coroutines.launch
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class LoginViewModel(private val pref: UserPreference) : ViewModel() {

private val _responseApi = MutableLiveData<String>()
val responseApi: LiveData<String> = _responseApi


    fun getUser(): LiveData<UserModel> {
        return pref.getUser().asLiveData()
    }
    companion object{
        private const val TAG = "LoginViewModel"
    }
    fun login(user:UserModel) {
        viewModelScope.launch {
            pref.login(user)
        }
    }
    fun userLogin(context: Context, email:String, password:String){
        val service= ApiConfig.getApiService().loginUser(email,password)
        service.enqueue(object : Callback<loginResponse> {
            override fun onResponse(
                call: Call<loginResponse>,
                response: Response<loginResponse>
            ) {
                val responseBody = response.body()
                if (response.isSuccessful && responseBody != null) {

                    Log.d("Test API", "TEST API NIH BOS")
                    val error = responseBody.error
                    if (!error) {
                        val user = UserModel(responseBody.loginResult.userId,
                            responseBody.loginResult.name,
                            responseBody.loginResult.token,true
                        )
                        login(user)
                    } else {
                        _responseApi.value = "Failed login"
                    }
                } else {
                    Log.e(TAG, "onFailure: ${response.message()}")
                }
            }
            override fun onFailure(call: Call<loginResponse>, t: Throwable) {
                _responseApi.value = t.message

                Log.e(TAG, "onFailure: ${t.message.toString()}")
            }
        })
}}
