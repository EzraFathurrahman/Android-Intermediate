package com.ezra.Sub2StoryApp.view.login

import com.google.gson.annotations.SerializedName

data class loginResponse(
    @field:SerializedName("error")
    val error: Boolean,
    @field:SerializedName("message")
    val message: String,
    @field:SerializedName("loginResult")
    val loginResult: loginData
)
